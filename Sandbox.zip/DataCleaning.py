import numpy as np
import pandas as pd


data=pd.read_csv('firedata.csv',encoding='utf-8')

# print(data.head())


